const https = require('https');
const fs = require('fs');
const path = require('path');

const iconsDir = path.join(__dirname, '..', 'icons');

if (!fs.existsSync(iconsDir)){
    fs.mkdirSync(iconsDir, { recursive: true });
}

// Icons8 offers high quality WhatsApp icons
const urls = {
  'icon16.png': 'https://img.icons8.com/color/16/whatsapp.png',
  'icon48.png': 'https://img.icons8.com/color/48/whatsapp.png',
  'icon128.png': 'https://img.icons8.com/color/96/whatsapp.png' // 96px or 120px is fine for 128
};

function download(filename, url) {
  return new Promise((resolve, reject) => {
    const file = fs.createWriteStream(path.join(iconsDir, filename));
    
    const request = https.get(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36'
      }
    }, (response) => {
      if (response.statusCode !== 200) {
        reject(new Error(`Failed to get '${url}' (${response.statusCode})`));
        return;
      }
      
      response.pipe(file);
      
      file.on('finish', () => {
        file.close();
        console.log(`Successfully downloaded ${filename}`);
        resolve();
      });
    });
    
    request.on('error', (err) => {
      fs.unlink(path.join(iconsDir, filename), () => {});
      reject(err);
    });
  });
}

async function run() {
  for (const [filename, url] of Object.entries(urls)) {
    try {
      await download(filename, url);
    } catch (err) {
      console.error(`Error downloading ${filename}:`, err);
    }
  }
}

run();
